import { fetchMessagesPage } from "@/lib/actions/conversation-actions";
import ChatRoom from "./ChatRoom"; // your client component
import { auth } from "@/auth";

export const dynamic = "force-dynamic";

export default async function ConversationPage({ params }) {
	const session = await auth();
	if (!session?.user?.id) return null;

	const { id } = await params; // other user's id for DM
	const {
		ok,
		conversationId,
		messages,
		nextCursor,
		title,
		peers,
		participants,
		viewerRole,
		viewerStatus,
	} =
		await fetchMessagesPage({ id, kind: "dm", limit: 30 });

	if (!ok) return null;

	return (
		<ChatRoom
			conversationId={conversationId}
			kind="dm"
			requestId={id}
			initialMessages={messages}
			initialCursor={nextCursor}
			title={title}
			peers={peers}
			participants={participants}
			viewerRole={viewerRole}
			viewerStatus={viewerStatus}
		/>
	);
}
