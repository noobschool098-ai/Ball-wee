// src/components/messages/ConversationsClient.jsx
"use client";

import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Avatar } from "@/components/Avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useOnlineUsers, useSocket } from "@/components/chat/useSocket";
import { useUser } from "@/components/providers/user-context";
import { usePathname, useRouter } from "next/navigation";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { UserRoundPlus } from "lucide-react";
import GroupChatDialog from "@/components/chat/GroupChatDialog";
import { formatGroupTitle } from "@/lib/chat-title";
import { useUnread } from "@/components/providers/unread-context";

function getLastActivityTimestamp(conversation) {
	const lastMessageAt = conversation?.messages?.[0]?.createdAt;
	if (lastMessageAt) {
		const ts = new Date(lastMessageAt).getTime();
		if (!Number.isNaN(ts)) return ts;
	}
	const updatedAt = conversation?.updatedAt;
	if (updatedAt) {
		const ts = new Date(updatedAt).getTime();
		if (!Number.isNaN(ts)) return ts;
	}
	return 0;
}

function sortConversationsByActivity(list = []) {
	return [...list].sort(
		(a, b) => getLastActivityTimestamp(b) - getLastActivityTimestamp(a)
	);
}

export default function ConversationsClient({
	initialItems = [],
	initialMembers = [],
	nextCursor = null,
}) {
	const viewer = useUser();
	const viewerId = viewer?.id ?? null;
	const socket = useSocket();
	const pathname = usePathname();
	const router = useRouter();
	const { syncUnreadTotal } = useUnread();

	const [isDialogOpen, setDialogOpen] = useState(false);

	const { routeId, routeKind } = useMemo(() => {
		if (!pathname) return { routeId: "", routeKind: "dm" };
		const parts = pathname.split("/").filter(Boolean);
		if (parts[0] !== "messages") return { routeId: "", routeKind: "dm" };
		const last = parts[parts.length - 1];
		if (last === "group")
			return { routeId: parts[1] || "", routeKind: "group" };
		if (last === "room") return { routeId: parts[1] || "", routeKind: "room" };
		return { routeId: parts[1] || "", routeKind: "dm" };
	}, [pathname]);

	const [items, setItems] = useState(() =>
		sortConversationsByActivity(initialItems)
	);
	useEffect(
		() => setItems(sortConversationsByActivity(initialItems)),
		[initialItems]
	);
	const unreadTotal = useMemo(
		() => items.reduce((sum, c) => sum + (c.unreadCount || 0), 0),
		[items]
	);
	const onlineUsers = useOnlineUsers();

	const [q, setQ] = useState("");
	const [tab, setTab] = useState("All");

	useEffect(() => {
		syncUnreadTotal(unreadTotal);
	}, [syncUnreadTotal, unreadTotal]);

	// --- NEW: track which rooms we've joined so we don't spam the server ---
	const joinedRef = useRef(new Set());
	// Prevent duplicate socket emissions from inflating local unread counts
	const seenMessagesRef = useRef({ ids: new Set(), order: [] });

	// Join all conversation rooms we know about; re-join on socket reconnect

	useEffect(() => {
		if (!socket) return;

		const joined = joinedRef.current;
		const joinOnce = (id) => {
			if (!id || joined.has(id)) return;
			socket.emit("conversation:join", { conversationId: id });
			joined.add(id);
		};

		items.forEach((c) => joinOnce(c.id));

		const onConnect = () => {
			joined.clear();
			items.forEach((c) => joinOnce(c.id));
		};
		socket.on("connect", onConnect);
		return () => socket.off("connect", onConnect);
	}, [socket, items]);

	// live updates
	useEffect(() => {
		if (!socket) return;

		const extractConversation = (payload) => {
			if (!payload) return null;
			if (payload.conversation) return payload.conversation;
			if (payload.room) return payload.room;
			return payload;
		};

		const onNewConversation = (payload) => {
			const conversation = extractConversation(payload);
			if (!conversation?.id) return;

			setItems((prev) => {
				if (prev.some((c) => c.id === conversation.id)) return prev;
				return sortConversationsByActivity([conversation, ...prev]);
			});

			// NEW: immediately join the newly created conversation room
			const joined = joinedRef.current;
			if (!joined.has(conversation.id)) {
				socket.emit("conversation:join", { conversationId: conversation.id });
				joined.add(conversation.id);
			}
		};

		const onNewMessage = ({ message }) => {
			if (!message?.conversationId) return;

			const messageId = message.id;
			if (messageId) {
				const seen = seenMessagesRef.current;
				if (seen.ids.has(messageId)) return;
				seen.ids.add(messageId);
				seen.order.push(messageId);
				if (seen.order.length > 200) {
					const oldest = seen.order.shift();
					if (oldest) seen.ids.delete(oldest);
				}
			}

			setItems((prev) => {
				const idx = prev.findIndex((c) => c.id === message.conversationId);
				if (idx === -1) return prev;

				const conv = prev[idx];
				const peers = (conv.participants || [])
					.map((p) => p.user)
					.filter(Boolean);
				const peerForDM =
					peers.find((u) => u?.id && u.id !== viewerId) || peers[0] || null;

				const fromOther = message.author?.id && message.author.id !== viewerId;
				const isActive =
					conv.isPublic || conv.isGroup
						? routeId === conv.id
						: routeKind === "dm" && peerForDM?.id && routeId === peerForDM.id;

				const unreadCount = Math.max(
					0,
					(conv.unreadCount || 0) + (fromOther && !isActive ? 1 : 0)
				);

				const updated = {
					...conv,
					unreadCount,
					messages: [message, ...(conv.messages ?? [])],
				};

				return [updated, ...prev.slice(0, idx), ...prev.slice(idx + 1)];
			});
		};

		const conversationEvents = [
			"conversation:new",
			"conversation:room:new",
			"room:new",
		];

		conversationEvents.forEach((event) => socket.on(event, onNewConversation));
		socket.on("message:new", onNewMessage);
		return () => {
			conversationEvents.forEach((event) =>
				socket.off(event, onNewConversation)
			);
			socket.off("message:new", onNewMessage);
		};
	}, [socket, viewerId, routeId, routeKind]);

	// zero local unread when viewing that conversation
	useEffect(() => {
		if (!routeId) return;
		setItems((prev) =>
			prev.map((c) => {
				if (c.isPublic || c.isGroup) {
					return c.id === routeId ? { ...c, unreadCount: 0 } : c;
				}
				const peers = (c.participants || []).map((p) => p.user).filter(Boolean);
				const peerForDM =
					peers.find((u) => u?.id && u.id !== viewerId) || peers[0] || null;
				return peerForDM?.id && peerForDM.id === routeId
					? { ...c, unreadCount: 0 }
					: c;
			})
		);
	}, [routeId, routeKind, viewerId]);

	// helper for DM title
	function getPeerAndTitle(c) {
		const peers = (c.participants || []).map((p) => p.user).filter(Boolean);
		const peerForDM =
			peers.find((u) => u?.id && u.id !== viewerId) || peers[0] || null;

		let title;
		if (c.isPublic) {
			title =
				c.title ||
				formatGroupTitle({
					participants: peers,
					viewerId,
					maxNames: 3,
					fallback: "Room",
				});
		} else if (c.isGroup) {
			title =
				c.title ||
				formatGroupTitle({
					participants: peers,
					viewerId,
					maxNames: 3,
					fallback: "Conversation",
				});
		} else {
			title = peerForDM?.name || "User";
		}

		return { peers, peerForDM, title };
	}

	const filtered = useMemo(() => {
		const needle = q.trim().toLowerCase();

		const bySearch = (c) => {
			if (!needle) return true;
			const { peers, title } = getPeerAndTitle(c);
			const hay = [
				title.toLowerCase(),
				...peers.map((u) => (u?.name || "").toLowerCase()),
			].join(" ");
			return hay.includes(needle);
		};

		const byTab = (c) => {
			if (tab === "All") return true;
			if (tab === "Unread") return (c.unreadCount || 0) > 0;
			if (tab === "Groups") return !!c.isGroup && !c.isPublic;
			if (tab === "Rooms") return !!c.isPublic;
			return true;
		};

		return items.filter((c) => bySearch(c) && byTab(c));
	}, [items, q, tab]);

	const handleGroupCreated = useCallback(
		(conversation) => {
			if (!conversation?.id) return;
			setItems((prev) => {
				const exists = prev.some((c) => c.id === conversation.id);
				const merged = exists
					? prev.map((c) =>
							c.id === conversation.id ? { ...c, ...conversation } : c
					  )
					: [conversation, ...prev];
				return sortConversationsByActivity(merged);
			});
			setDialogOpen(false);
			router.push(`/messages/${conversation.id}/group`);
		},
		[router]
	);

	return (
		<main className="max-w-[700px] w-full h-[93vh]">
			<Card className="rounded-none h-full">
				<div className="flex flex-row items-center justify-between px-2">
					<h1 className="text-xl font-semibold ">Messages</h1>
					<Dialog open={isDialogOpen} onOpenChange={setDialogOpen}>
						<DialogTrigger asChild>
							<Button
								className="rounded-full p-0 cursor-pointer bg-muted h-10 w-10 shadow-2xl hover:bg-accent-foreground"
								variant="icon"
								onClick={() => setDialogOpen(true)}
							>
								<UserRoundPlus className="size-5 p-0" />
							</Button>
						</DialogTrigger>
						<DialogContent className="space-y-4 sm:max-w-lg">
							<GroupChatDialog
								initialMembers={initialMembers}
								nextCursor={nextCursor}
								onCreated={handleGroupCreated}
							/>
						</DialogContent>
					</Dialog>
				</div>

				<div className="px-2 pb-2">
					<input
						value={q}
						onChange={(e) => setQ(e.target.value)}
						placeholder="Search conversations…"
						className="w-full px-3 py-2 text-sm bg-accent rounded-md outline-none"
					/>
				</div>

				<div className="px-2 border-b dark:border-gray-500">
					<div className="flex gap-3">
						{["All", "Unread", "Groups", "Rooms"].map((t) => (
							<button
								key={t}
								onClick={() => setTab(t)}
								className={`border-b-2 px-2 py-1 text-xs cursor-pointer ${
									tab === t
										? "border-primary text-primary font-medium"
										: "border-transparent text-gray-500 hover:text-foreground-muted hover:border-gray-300"
								}`}
							>
								<span className="inline-flex items-center gap-1">
									{t}
									{t === "Unread" && unreadTotal > 0 && (
										<span className="min-w-[15px] h-[15px] px-1 rounded-full bg-red-500 text-white text-[10px] leading-[18px] flex items-center justify-center">
											{unreadTotal > 99 ? "99+" : unreadTotal}
										</span>
									)}
								</span>
							</button>
						))}
					</div>
				</div>

				<ScrollArea className="overflow-y-auto">
					{filtered.map((c) => {
						const { peerForDM, title } = getPeerAndTitle(c);
						const last = c.messages?.[0];

						let href = "";
						if (c.isPublic) href = `/messages/${c.id}/room`;
						else if (c.isGroup) href = `/messages/${c.id}/group`;
						else href = `/messages/${peerForDM?.id || c.id}`;

						const isActive =
							c.isPublic || c.isGroup
								? routeId === c.id
								: peerForDM?.id && routeId === peerForDM.id;
						const onlineStatus = onlineUsers.some(
							(user) => user.userId === peerForDM.id
						);

						return (
							<Card
								key={c.id}
								className={`p-3 flex justify-between rounded-none border-muted w-full max-w-[350px] ${
									isActive ? "bg-primary/10" : ""
								}`}
							>
								<div className="flex items-center gap-3">
									<Avatar
										src={peerForDM?.image}
										size={36}
										userId={peerForDM.id}
										isOnline={onlineStatus}
									/>
									<div className="text-sm">
										<Link href={href}>
											<div className="font-medium hover:underline max-w-[200px] overflow-ellipsis">
												{title}
											</div>
										</Link>
										{last ? (
											<div
												className={`text-xs opacity-70 overflow-ellipsis truncate w-[230px] ${
													c.unreadCount > 0 ? "font-bold" : ""
												}`}
											>
												{last.author?.id === viewerId
													? "You: "
													: `${last.author?.name ?? ""}: `}
												{last.attachments?.length
													? "[attachment]"
													: last.content}
											</div>
										) : (
											<div className="text-xs opacity-70">No messages yet</div>
										)}
									</div>
									{(c.unreadCount || 0) > 0 && (
										<div className="flex items-center flex-row">
											<span className="min-w-[20px] h-[20px] px-1 rounded-full bg-red-500 text-white text-[11px] flex items-center justify-center">
												{c.unreadCount > 99 ? "99+" : c.unreadCount}
											</span>
										</div>
									)}
								</div>
							</Card>
						);
					})}
				</ScrollArea>
			</Card>
		</main>
	);
}
