import {
	Card,
	CardContent,
	CardDescription,
	CardHeader,
	CardTitle,
} from "../ui/card";
import prisma from "@/lib/prisma";
import { auth } from "@/auth";
import DiscoverWidget from "../discover/DiscoverWidget";
export const dynamic = "force-dynamic";

const LIMIT = 12;

export default async function RightSideBar() {
	const session = await auth();
	const viewerId = session?.user?.id ?? null;
	const viewerRole = session?.user?.role ?? "USER";

	const rows = await prisma.user.findMany({
		where: { id: { not: viewerId } },
		take: LIMIT + 1,
		orderBy: [
			{ followers: { _count: "desc" } },
			{ following: { _count: "desc" } },
			{ id: "desc" },
		],
		select: {
			id: true,
			name: true,
			email: true,
			image: true,
			role: true,
			bio: true,
			coverImageUrl: true,
			_count: { select: { followers: true, following: true } },
		},
	});

	let nextCursor = null;
	if (rows.length > LIMIT) nextCursor = rows[rows.length - 1].id;
	const users = rows.slice(0, LIMIT);

	// follow flags for initial batch
	let followSet = new Set();
	let backSet = new Set();
	if (viewerId && users.length) {
		const ids = users.map((u) => u.id);
		const edges = await prisma.follow.findMany({
			where: {
				OR: [
					{ followerId: viewerId, followingId: { in: ids } },
					{ followerId: { in: ids }, followingId: viewerId },
				],
			},
			select: { followerId: true, followingId: true },
		});
		followSet = new Set(
			edges.filter((e) => e.followerId === viewerId).map((e) => e.followingId)
		);
		backSet = new Set(
			edges.filter((e) => e.followingId === viewerId).map((e) => e.followerId)
		);
	}

	const initialUsers = users.map((u) => ({
		...u,
		isFollowedByMe: followSet.has(u.id),
		followsMe: backSet.has(u.id),
	}));

	return (
		<div className="h-[93vh] flex flex-col gap-6 justify-start p-6  overflow-y-auto">
			<Card className="h-75 ">
				<CardHeader>
					<CardTitle>Updates</CardTitle>
				</CardHeader>
				<CardContent>
					<CardTitle>Welcome to YapSpace!</CardTitle>
					<CardDescription className="mt-2 text-sm overflow-hidden max-h-20">
						Lorem ipsum dolor sit amet consectetur, adipisicing elit. Unde sunt
						ad deserunt quibusdam enim facilis itaque facere est fugiat
						voluptatibus libero omnis adipisci, eaque necessitatibus debitis
						placeat totam vel eligendi.
					</CardDescription>
				</CardContent>
			</Card>
			<DiscoverWidget
				initialUsers={initialUsers}
				initialNextCursor={nextCursor}
				viewerId={viewerId}
				viewerRole={viewerRole}
			/>
		</div>
	);
}
